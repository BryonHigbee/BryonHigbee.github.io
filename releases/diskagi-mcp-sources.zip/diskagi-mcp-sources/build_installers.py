#!/usr/bin/env python3
"""Build the DiskAGI Universal MCP Setup Installers & Portable Source Bundle (`build_installers.py`):
  1. `/home/bryonh/Documents/DiskNCM/dist/DiskAGI-MCP-Setup-x86_64.AppImage` (Linux x86_64 AppImage)
  2. `/home/bryonh/Documents/DiskNCM/dist/DiskAGI-MCP-Setup-Windows-x64.exe` (Windows x64 PE32+ .exe)
  3. `/home/bryonh/Documents/DiskNCM/dist/diskagi-mcp-sources/` + `diskagi-mcp-sources.zip` (Full Sources)
"""
from __future__ import annotations

import shutil
import subprocess
import tarfile
import zipfile
from pathlib import Path

REPO_ROOT = Path("/home/bryonh/Documents/DiskNCM")
PLUGIN_DIR = REPO_ROOT / "plugin"
DIST_DIR = REPO_ROOT / "dist"
SRC_BUNDLE_DIR = DIST_DIR / "diskagi-mcp-sources"
GH_PAGES_DIR = Path("/home/bryonh/Documents/BryonHigbee.github.io")


def _c_byte_array(data: bytes, var_name: str) -> str:
    hex_items = ", ".join(f"0x{b:02x}" for b in data)
    return (
        f"static const unsigned char {var_name}[] = {{ {hex_items} }};\n"
        f"static const unsigned int {var_name}_len = {len(data)}U;\n"
    )


def build_all() -> None:
    DIST_DIR.mkdir(parents=True, exist_ok=True)
    SRC_BUNDLE_DIR.mkdir(parents=True, exist_ok=True)

    standalone_py = (PLUGIN_DIR / "diskagi_mcp_standalone.py").read_bytes()
    setup_py = (PLUGIN_DIR / "setup_harnesses.py").read_bytes()
    svg_logo = (REPO_ROOT / "agentos" / "static" / "diskncm-mark.svg").read_bytes()

    # Copy core Python sources into dist/diskagi-mcp-sources/
    (SRC_BUNDLE_DIR / "diskagi_mcp_standalone.py").write_bytes(standalone_py)
    (SRC_BUNDLE_DIR / "setup_harnesses.py").write_bytes(setup_py)
    (SRC_BUNDLE_DIR / "diskagi.svg").write_bytes(svg_logo)

    # Write install.sh and install.ps1
    install_sh = """#!/usr/bin/env sh
# DiskAGI Standalone MCP + Vision/Video + Local->Cloud Failover Auto-Setup (Linux & macOS)
set -eu
SHARE_DIR="${HOME}/.local/share/diskagi-mcp"
mkdir -p "$SHARE_DIR"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if [ -f "$SCRIPT_DIR/diskagi_mcp_standalone.py" ]; then
    cp "$SCRIPT_DIR/diskagi_mcp_standalone.py" "$SHARE_DIR/diskagi_mcp_standalone.py"
    cp "$SCRIPT_DIR/setup_harnesses.py" "$SHARE_DIR/setup_harnesses.py"
else
    curl -fsSL "https://bryonhigbee.github.io/releases/diskagi_mcp_standalone.py" -o "$SHARE_DIR/diskagi_mcp_standalone.py"
    curl -fsSL "https://bryonhigbee.github.io/releases/setup_harnesses.py" -o "$SHARE_DIR/setup_harnesses.py"
fi
chmod +x "$SHARE_DIR/diskagi_mcp_standalone.py" "$SHARE_DIR/setup_harnesses.py"
python3 "$SHARE_DIR/setup_harnesses.py"
"""
    install_ps1 = """# DiskAGI Standalone MCP + Vision/Video + Local->Cloud Failover Auto-Setup (Windows PowerShell)
$ErrorActionPreference = "Stop"
$ShareDir = Join-Path $env:LOCALAPPDATA "DiskAGI-MCP"
New-Item -ItemType Directory -Force -Path $ShareDir | Out-Null
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ($ScriptDir -and (Test-Path (Join-Path $ScriptDir "diskagi_mcp_standalone.py"))) {
    Copy-Item (Join-Path $ScriptDir "diskagi_mcp_standalone.py") (Join-Path $ShareDir "diskagi_mcp_standalone.py") -Force
    Copy-Item (Join-Path $ScriptDir "setup_harnesses.py") (Join-Path $ShareDir "setup_harnesses.py") -Force
} else {
    Invoke-WebRequest -Uri "https://bryonhigbee.github.io/releases/diskagi_mcp_standalone.py" -OutFile (Join-Path $ShareDir "diskagi_mcp_standalone.py") -UseBasicParsing
    Invoke-WebRequest -Uri "https://bryonhigbee.github.io/releases/setup_harnesses.py" -OutFile (Join-Path $ShareDir "setup_harnesses.py") -UseBasicParsing
}
python (Join-Path $ShareDir "setup_harnesses.py")
"""
    (SRC_BUNDLE_DIR / "install.sh").write_text(install_sh, encoding="utf-8")
    (SRC_BUNDLE_DIR / "install.sh").chmod(0o755)
    (SRC_BUNDLE_DIR / "install.ps1").write_text(install_ps1, encoding="utf-8")

    # ── 1. Build Linux AppImage (`DiskAGI-MCP-Setup-x86_64.AppImage`) ─────────
    appdir = DIST_DIR / "AppDir"
    if appdir.exists():
        shutil.rmtree(appdir)
    (appdir / "usr" / "bin").mkdir(parents=True, exist_ok=True)
    (appdir / "usr" / "bin" / "diskagi_mcp_standalone.py").write_bytes(standalone_py)
    (appdir / "usr" / "bin" / "setup_harnesses.py").write_bytes(setup_py)
    (appdir / "usr" / "bin" / "diskagi_mcp_standalone.py").chmod(0o755)
    (appdir / "usr" / "bin" / "setup_harnesses.py").chmod(0o755)
    (appdir / "diskagi.svg").write_bytes(svg_logo)
    (appdir / "diskagi-mcp-setup.desktop").write_text(
        "[Desktop Entry]\n"
        "Type=Application\n"
        "Name=DiskAGI MCP Setup\n"
        "Comment=Automated Multi-Harness DiskAGI Brain & Vision/Video MCP Installer\n"
        "Exec=AppRun\n"
        "Icon=diskagi\n"
        "Categories=Development;Utility;\n"
        "Terminal=true\n",
        encoding="utf-8",
    )
    apprun = (
        "#!/usr/bin/env sh\n"
        "set -eu\n"
        "HERE=\"$(dirname \"$(readlink -f \"$0\")\")\"\n"
        "SHARE_DIR=\"${HOME}/.local/share/diskagi-mcp\"\n"
        "mkdir -p \"$SHARE_DIR\"\n"
        "cp \"$HERE/usr/bin/diskagi_mcp_standalone.py\" \"$SHARE_DIR/diskagi_mcp_standalone.py\"\n"
        "cp \"$HERE/usr/bin/setup_harnesses.py\" \"$SHARE_DIR/setup_harnesses.py\"\n"
        "chmod +x \"$SHARE_DIR/diskagi_mcp_standalone.py\" \"$SHARE_DIR/setup_harnesses.py\"\n"
        "exec python3 \"$SHARE_DIR/setup_harnesses.py\" \"$@\"\n"
    )
    (appdir / "AppRun").write_text(apprun, encoding="utf-8")
    (appdir / "AppRun").chmod(0o755)

    tar_gz_path = DIST_DIR / "appdir_payload.tar.gz"
    with tarfile.open(tar_gz_path, "w:gz") as tf:
        for item in sorted(appdir.rglob("*")):
            tf.add(item, arcname=f"squashfs-root/{item.relative_to(appdir)}")
    tar_bytes = tar_gz_path.read_bytes()
    tar_gz_path.unlink(missing_ok=True)
    shutil.rmtree(appdir, ignore_errors=True)

    linux_c_hdr = _c_byte_array(tar_bytes, "APPDIR_TAR_GZ")
    linux_c_src = f"""/* DiskAGI-MCP-Setup-x86_64.AppImage Self-Extracting AppImage Runtime (Linux x86_64) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>

{linux_c_hdr}

int main(int argc, char **argv) {{
    if (argc > 1 && strcmp(argv[1], "--appimage-help") == 0) {{
        printf("DiskAGI-MCP-Setup-x86_64.AppImage\\n");
        printf("  --appimage-extract   Extract AppDir contents to ./squashfs-root\\n");
        printf("  --appimage-version   Print AppImage version\\n");
        return 0;
    }}
    if (argc > 1 && strcmp(argv[1], "--appimage-version") == 0) {{
        printf("DiskAGI-MCP-Setup AppImage v2.0.0\\n");
        return 0;
    }}
    int extract_only = (argc > 1 && strcmp(argv[1], "--appimage-extract") == 0);
    char tmp_dir[512];
    if (extract_only) {{
        snprintf(tmp_dir, sizeof(tmp_dir), ".");
    }} else {{
        snprintf(tmp_dir, sizeof(tmp_dir), "/tmp/diskagi-appimage-%d", (int)getpid());
        mkdir(tmp_dir, 0700);
    }}
    char tar_file[600];
    snprintf(tar_file, sizeof(tar_file), "%s/.payload.tar.gz", tmp_dir);
    FILE *fp = fopen(tar_file, "wb");
    if (!fp) {{
        perror("fopen payload");
        return 1;
    }}
    fwrite(APPDIR_TAR_GZ, 1, APPDIR_TAR_GZ_len, fp);
    fclose(fp);

    char cmd[1400];
    snprintf(cmd, sizeof(cmd), "tar -xzf '%s' -C '%s' && rm -f '%s'", tar_file, tmp_dir, tar_file);
    if (system(cmd) != 0) {{
        fprintf(stderr, "Failed to unpack AppDir payload\\n");
        return 1;
    }}
    if (extract_only) {{
        printf("Extracted AppDir to ./squashfs-root\\n");
        return 0;
    }}
    snprintf(cmd, sizeof(cmd), "'%s/squashfs-root/AppRun'", tmp_dir);
    int rc = system(cmd);
    char cleanup[700];
    snprintf(cleanup, sizeof(cleanup), "rm -rf '%s'", tmp_dir);
    system(cleanup);
    return WIFEXITED(rc) ? WEXITSTATUS(rc) : 0;
}}
"""
    (SRC_BUNDLE_DIR / "linux_appimage_main.c").write_text(linux_c_src, encoding="utf-8")
    appimage_out = DIST_DIR / "DiskAGI-MCP-Setup-x86_64.AppImage"
    subprocess.run(
        ["gcc", "-O2", str(SRC_BUNDLE_DIR / "linux_appimage_main.c"), "-o", str(appimage_out)],
        check=True,
    )
    appimage_out.chmod(0o755)
    # Stamp AppImage Type 2 magic bytes ("AI\x02") at ELF header e_ident[8..10]
    raw_elf = bytearray(appimage_out.read_bytes())
    raw_elf[8:11] = b"AI\x02"
    appimage_out.write_bytes(bytes(raw_elf))

    # ── 2. Build Windows 64-bit Native Executable (`DiskAGI-MCP-Setup-Windows-x64.exe`) ──
    win_c_hdr = (
        _c_byte_array(standalone_py, "STANDALONE_PY")
        + "\n"
        + _c_byte_array(setup_py, "SETUP_PY")
    )
    win_c_src = r"""/* DiskAGI-MCP-Setup-Windows-x64.exe — Native 64-Bit Windows PE32+ Installer
 * Unpacks `diskagi_mcp_standalone.py` + `setup_harnesses.py` to `%LOCALAPPDATA%\DiskAGI-MCP`
 * and automatically wires `diskncm-brain` MCP (with Local -> Cloud Brain failover, Laya +
 * 16-Domain router, 20-Slot Human Working Memory, and pure-CPU Vision/Video Bridge) into:
 *   - Oh-My-Pi (`omp`):    %USERPROFILE%\.omp\agent\mcp.json
 *   - Claude Code:         %USERPROFILE%\.claude.json
 *   - Claude Desktop:      %APPDATA%\Claude\claude_desktop_config.json
 *   - OpenCode:            %USERPROFILE%\.config\opencode\opencode.json
 *   - OpenAI Codex:        %USERPROFILE%\.codex\mcp.json
 *   - Cursor IDE:          %USERPROFILE%\.cursor\mcp.json
 *   - Windsurf IDE:        %USERPROFILE%\.codeium\windsurf\mcp_config.json
 *   - Zed Editor:          %USERPROFILE%\.config\zed\settings.json
 */
typedef unsigned int DWORD;
typedef int BOOL;
typedef void *HANDLE;
typedef const char *LPCSTR;
typedef char *LPSTR;

#define GENERIC_WRITE 0x40000000U
#define CREATE_ALWAYS 2U
#define FILE_ATTRIBUTE_NORMAL 0x80U
#define STD_OUTPUT_HANDLE ((DWORD)-11)
#define INVALID_HANDLE_VALUE ((HANDLE)(long long)-1)

typedef struct _STARTUPINFOA {
    DWORD cb;
    LPSTR lpReserved;
    LPSTR lpDesktop;
    LPSTR lpTitle;
    DWORD dwX;
    DWORD dwY;
    DWORD dwXSize;
    DWORD dwYSize;
    DWORD dwXCountChars;
    DWORD dwYCountChars;
    DWORD dwFillAttribute;
    DWORD dwFlags;
    unsigned short wShowWindow;
    unsigned short cbReserved2;
    unsigned char *lpReserved2;
    HANDLE hStdInput;
    HANDLE hStdOutput;
    HANDLE hStdError;
} STARTUPINFOA;

typedef struct _PROCESS_INFORMATION {
    HANDLE hProcess;
    HANDLE hThread;
    DWORD dwProcessId;
    DWORD dwThreadId;
} PROCESS_INFORMATION;

__declspec(dllimport) DWORD __stdcall GetEnvironmentVariableA(LPCSTR lpName, LPSTR lpBuffer, DWORD nSize);
__declspec(dllimport) BOOL __stdcall CreateDirectoryA(LPCSTR lpPathName, void *lpSecurityAttributes);
__declspec(dllimport) HANDLE __stdcall CreateFileA(LPCSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, void *lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile);
__declspec(dllimport) BOOL __stdcall WriteFile(HANDLE hFile, const void *lpBuffer, DWORD nNumberOfBytesToWrite, DWORD *lpNumberOfBytesWritten, void *lpOverlapped);
__declspec(dllimport) BOOL __stdcall CloseHandle(HANDLE hObject);
__declspec(dllimport) HANDLE __stdcall GetStdHandle(DWORD nStdHandle);
__declspec(dllimport) BOOL __stdcall CreateProcessA(LPCSTR lpApplicationName, LPSTR lpCommandLine, void *lpProcessAttributes, void *lpThreadAttributes, BOOL bInheritHandles, DWORD dwCreationFlags, void *lpEnvironment, LPCSTR lpCurrentDirectory, STARTUPINFOA *lpStartupInfo, PROCESS_INFORMATION *lpProcessInformation);
__declspec(dllimport) DWORD __stdcall WaitForSingleObject(HANDLE hHandle, DWORD dwMilliseconds);
__declspec(dllimport) void __stdcall ExitProcess(DWORD uExitCode);

int _fltused = 0;

static unsigned int my_strlen(const char *s) {
    unsigned int n = 0;
    while (s[n]) n++;
    return n;
}

static void my_strcpy(char *dst, const char *src) {
    while ((*dst++ = *src++) != 0) {}
}

static void my_strcat(char *dst, const char *src) {
    while (*dst) dst++;
    while ((*dst++ = *src++) != 0) {}
}

static void print_str(const char *s) {
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    if (hOut != INVALID_HANDLE_VALUE) {
        DWORD written = 0;
        WriteFile(hOut, s, my_strlen(s), &written, 0);
    }
}

static void ensure_dir_tree(const char *path) {
    char buf[1024];
    my_strcpy(buf, path);
    for (unsigned int i = 0; buf[i]; i++) {
        if ((buf[i] == '\\' || buf[i] == '/') && i > 2) {
            char saved = buf[i];
            buf[i] = 0;
            CreateDirectoryA(buf, 0);
            buf[i] = saved;
        }
    }
    CreateDirectoryA(buf, 0);
}

static int write_bytes_file(const char *path, const void *data, unsigned int len) {
    HANDLE h = CreateFileA(path, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
    if (h == INVALID_HANDLE_VALUE) return 0;
    DWORD written = 0;
    WriteFile(h, data, len, &written, 0);
    CloseHandle(h);
    return written == len;
}

static void escape_json_path(char *out, const char *in_p) {
    unsigned int j = 0;
    for (unsigned int i = 0; in_p[i]; i++) {
        if (in_p[i] == '\\') {
            out[j++] = '\\';
            out[j++] = '\\';
        } else {
            out[j++] = in_p[i];
        }
    }
    out[j] = 0;
}

static void write_mcp_config_json(const char *dir_path, const char *file_path, const char *escaped_py_script, int is_opencode) {
    ensure_dir_tree(dir_path);
    char json_buf[2048];
    json_buf[0] = 0;
    if (is_opencode) {
        my_strcat(json_buf, "{\n  \"mcp\": {\n    \"diskncm-brain\": {\n      \"type\": \"local\",\n      \"command\": [\"python\", \"");
        my_strcat(json_buf, escaped_py_script);
        my_strcat(json_buf, "\"],\n      \"enabled\": true\n    }\n  }\n}\n");
    } else {
        my_strcat(json_buf, "{\n  \"mcpServers\": {\n    \"diskncm-brain\": {\n      \"type\": \"stdio\",\n      \"command\": \"python\",\n      \"args\": [\"");
        my_strcat(json_buf, escaped_py_script);
        my_strcat(json_buf, "\"],\n      \"enabled\": true\n    }\n  }\n}\n");
    }
    write_bytes_file(file_path, json_buf, my_strlen(json_buf));
}

__WIN_C_HDR__

void mainCRTStartup(void) {
    char userprofile[512];
    char localappdata[512];
    char appdata[512];
    if (!GetEnvironmentVariableA("USERPROFILE", userprofile, sizeof(userprofile))) {
        my_strcpy(userprofile, "C:\\Users\\Default");
    }
    if (!GetEnvironmentVariableA("LOCALAPPDATA", localappdata, sizeof(localappdata))) {
        my_strcpy(localappdata, userprofile);
        my_strcat(localappdata, "\\AppData\\Local");
    }
    if (!GetEnvironmentVariableA("APPDATA", appdata, sizeof(appdata))) {
        my_strcpy(appdata, userprofile);
        my_strcat(appdata, "\\AppData\\Roaming");
    }

    char install_dir[600];
    my_strcpy(install_dir, localappdata);
    my_strcat(install_dir, "\\DiskAGI-MCP");
    ensure_dir_tree(install_dir);

    char standalone_path[700];
    my_strcpy(standalone_path, install_dir);
    my_strcat(standalone_path, "\\diskagi_mcp_standalone.py");
    write_bytes_file(standalone_path, STANDALONE_PY, STANDALONE_PY_len);

    char setup_path[700];
    my_strcpy(setup_path, install_dir);
    my_strcat(setup_path, "\\setup_harnesses.py");
    write_bytes_file(setup_path, SETUP_PY, SETUP_PY_len);

    char esc_script[1024];
    escape_json_path(esc_script, standalone_path);

    /* Wire into Oh-My-Pi (omp), Claude Code, Claude Desktop, OpenCode, Codex, Cursor, Windsurf */
    char dir_b[700], file_b[750];

    my_strcpy(dir_b, userprofile); my_strcat(dir_b, "\\.omp\\agent");
    my_strcpy(file_b, dir_b); my_strcat(file_b, "\\mcp.json");
    write_mcp_config_json(dir_b, file_b, esc_script, 0);

    my_strcpy(dir_b, userprofile);
    my_strcpy(file_b, userprofile); my_strcat(file_b, "\\.claude.json");
    write_mcp_config_json(dir_b, file_b, esc_script, 0);

    my_strcpy(dir_b, appdata); my_strcat(dir_b, "\\Claude");
    my_strcpy(file_b, dir_b); my_strcat(file_b, "\\claude_desktop_config.json");
    write_mcp_config_json(dir_b, file_b, esc_script, 0);

    my_strcpy(dir_b, userprofile); my_strcat(dir_b, "\\.config\\opencode");
    my_strcpy(file_b, dir_b); my_strcat(file_b, "\\opencode.json");
    write_mcp_config_json(dir_b, file_b, esc_script, 1);

    my_strcpy(dir_b, userprofile); my_strcat(dir_b, "\\.codex");
    my_strcpy(file_b, dir_b); my_strcat(file_b, "\\mcp.json");
    write_mcp_config_json(dir_b, file_b, esc_script, 0);

    my_strcpy(dir_b, userprofile); my_strcat(dir_b, "\\.cursor");
    my_strcpy(file_b, dir_b); my_strcat(file_b, "\\mcp.json");
    write_mcp_config_json(dir_b, file_b, esc_script, 0);

    my_strcpy(dir_b, userprofile); my_strcat(dir_b, "\\.codeium\\windsurf");
    my_strcpy(file_b, dir_b); my_strcat(file_b, "\\mcp_config.json");
    write_mcp_config_json(dir_b, file_b, esc_script, 0);

    /* Also run python setup_harnesses.py if python is in PATH to preserve existing keys */
    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    for (unsigned int i = 0; i < sizeof(si); i++) ((unsigned char *)&si)[i] = 0;
    for (unsigned int i = 0; i < sizeof(pi); i++) ((unsigned char *)&pi)[i] = 0;
    si.cb = sizeof(si);
    char cmdline[900];
    my_strcpy(cmdline, "python \"");
    my_strcat(cmdline, setup_path);
    my_strcat(cmdline, "\"");
    if (CreateProcessA(0, cmdline, 0, 0, 0, 0, 0, 0, &si, &pi)) {
        WaitForSingleObject(pi.hProcess, 15000);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }

    print_str("{\n");
    print_str("  \"ok\": true,\n");
    print_str("  \"installer\": \"DiskAGI-MCP-Setup-Windows-x64.exe\",\n");
    print_str("  \"standalone_mcp_server\": \"");
    print_str(esc_script);
    print_str("\",\n");
    print_str("  \"failover_policy\": \"Local Brain -> Cloud Brain (automatic when Linux or Local Brain is off)\",\n");
    print_str("  \"harnesses_configured\": [\"Oh-My-Pi (omp)\", \"Claude Code\", \"Claude Desktop\", \"OpenCode\", \"Codex\", \"Cursor\", \"Windsurf\"]\n");
    print_str("}\n");
    ExitProcess(0);
}
""".replace("__WIN_C_HDR__", win_c_hdr)
    (SRC_BUNDLE_DIR / "windows_setup_main.c").write_text(win_c_src, encoding="utf-8")
    k32_def = (
        "LIBRARY kernel32.dll\n"
        "EXPORTS\n"
        "GetEnvironmentVariableA\n"
        "CreateDirectoryA\n"
        "CreateFileA\n"
        "WriteFile\n"
        "CloseHandle\n"
        "GetStdHandle\n"
        "CreateProcessA\n"
        "WaitForSingleObject\n"
        "ExitProcess\n"
    )
    def_path = SRC_BUNDLE_DIR / "kernel32.def"
    def_path.write_text(k32_def, encoding="utf-8")
    lib_path = DIST_DIR / "kernel32.lib"
    obj_path = DIST_DIR / "windows_setup_main.obj"
    exe_out = DIST_DIR / "DiskAGI-MCP-Setup-Windows-x64.exe"

    subprocess.run(["llvm-dlltool", "-m", "i386:x86-64", "-d", str(def_path), "-l", str(lib_path)], check=True)
    subprocess.run(
        [
            "clang", "-target", "x86_64-pc-windows-msvc", "-O2",
            "-fno-builtin", "-fno-stack-protector", "-mno-stack-arg-probe",
            "-c", str(SRC_BUNDLE_DIR / "windows_setup_main.c"),
            "-o", str(obj_path),
        ],
        check=True,
    )
    subprocess.run(
        [
            "lld-link", "/subsystem:console", "/entry:mainCRTStartup",
            f"/out:{exe_out}", str(obj_path), str(lib_path),
        ],
        check=True,
    )
    lib_path.unlink(missing_ok=True)
    obj_path.unlink(missing_ok=True)

    readme = """# DiskAGI Standalone MCP + Vision/Video + Local->Cloud Failover Setup

## 1. Ready-to-Run Installers (`dist/`)
- **Linux AppImage:** `DiskAGI-MCP-Setup-x86_64.AppImage`
  ```bash
  chmod +x DiskAGI-MCP-Setup-x86_64.AppImage
  ./DiskAGI-MCP-Setup-x86_64.AppImage
  ```
- **Windows 64-Bit Executable:** `DiskAGI-MCP-Setup-Windows-x64.exe`
  ```powershell
  .\\DiskAGI-MCP-Setup-Windows-x64.exe
  ```

## 2. What It Automatically Configures (Linux + Windows Dual-Boot)
- Wires `diskncm-brain` MCP into **Oh-My-Pi (`omp`)**, **Claude Code (`claude`)**, **Claude Desktop**, **OpenCode (`opencode`)**, **OpenAI Codex (`codex`)**, **Cursor**, **Windsurf**, and **Zed**.
- **Automatic Local -> Cloud Brain Failover:** Uses the Local Compressed Brain when available, and automatically fails over to the Google Drive Cloud Brain (`G:\\My Drive\\DiskNCM\\Brain` on Windows or `~/GoogleDrive/DiskNCM/Brain` on Linux) when the Local Brain or Linux is off.
- **No Local 4B LLM Required:** Runs Laya System-1 + 16-Domain & 844-DevDocs routing + 20-Slot Human Working Memory + Pure-CPU Vision & Video Bridge (`vision_inspect_image`, `vision_watch_video`) on CPU inside any harness with any model.
"""
    (SRC_BUNDLE_DIR / "README.md").write_text(readme, encoding="utf-8")
    shutil.copy2( Path(__file__).resolve(), SRC_BUNDLE_DIR / "build_installers.py" )

    # Zip the sources bundle for easy sending
    zip_out = DIST_DIR / "diskagi-mcp-sources.zip"
    with zipfile.ZipFile(zip_out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(SRC_BUNDLE_DIR.rglob("*")):
            if f.is_file():
                zf.write(f, arcname=f"diskagi-mcp-sources/{f.relative_to(SRC_BUNDLE_DIR)}")

    # Publish to GitHub Pages (`BryonHigbee.github.io/releases/`) so Windows dual-boot can download 24/7
    rel_dir = GH_PAGES_DIR / "releases"
    rel_dir.mkdir(parents=True, exist_ok=True)
    for item in (
        appimage_out,
        exe_out,
        zip_out,
        SRC_BUNDLE_DIR / "diskagi_mcp_standalone.py",
        SRC_BUNDLE_DIR / "setup_harnesses.py",
        SRC_BUNDLE_DIR / "install.sh",
        SRC_BUNDLE_DIR / "install.ps1",
    ):
        shutil.copy2(item, rel_dir / item.name)
    shutil.copy2(SRC_BUNDLE_DIR / "install.sh", GH_PAGES_DIR / "install.sh")
    shutil.copy2(SRC_BUNDLE_DIR / "install.ps1", GH_PAGES_DIR / "install.ps1")

    print(f"Built Linux AppImage : {appimage_out} ({appimage_out.stat().st_size:,} bytes)")
    print(f"Built Windows EXE    : {exe_out} ({exe_out.stat().st_size:,} bytes)")
    print(f"Built Source Bundle  : {zip_out} ({zip_out.stat().st_size:,} bytes)")


if __name__ == "__main__":
    build_all()
