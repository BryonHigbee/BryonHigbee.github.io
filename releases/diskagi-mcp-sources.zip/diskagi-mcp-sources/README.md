# DiskAGI Standalone MCP + Vision/Video + Local->Cloud Failover Setup

## 1. Ready-to-Run Installers (`dist/`)
- **Linux AppImage:** `DiskAGI-MCP-Setup-x86_64.AppImage`
  ```bash
  chmod +x DiskAGI-MCP-Setup-x86_64.AppImage
  ./DiskAGI-MCP-Setup-x86_64.AppImage
  ```
- **Windows 64-Bit Executable:** `DiskAGI-MCP-Setup-Windows-x64.exe`
  ```powershell
  .\DiskAGI-MCP-Setup-Windows-x64.exe
  ```

## 2. What It Automatically Configures (Linux + Windows Dual-Boot)
- Wires `diskncm-brain` MCP into **Oh-My-Pi (`omp`)**, **Claude Code (`claude`)**, **Claude Desktop**, **OpenCode (`opencode`)**, **OpenAI Codex (`codex`)**, **Cursor**, **Windsurf**, and **Zed**.
- **Automatic Local -> Cloud Brain Failover:** Uses the Local Compressed Brain when available, and automatically fails over to the Google Drive Cloud Brain (`G:\My Drive\DiskNCM\Brain` on Windows or `~/GoogleDrive/DiskNCM/Brain` on Linux) when the Local Brain or Linux is off.
- **No Local 4B LLM Required:** Runs Laya System-1 + 16-Domain & 844-DevDocs routing + 20-Slot Human Working Memory + Pure-CPU Vision & Video Bridge (`vision_inspect_image`, `vision_watch_video`) on CPU inside any harness with any model.
